# Elite Motors

Este será o projeto final do quarto bimestre da disciplina de banco de dados e autoria web,
que tem como objetivo o desenvolvimento de um site de e-commerce. O nosso domínio de aplicação será simular uma concessionária, 
um site de vendas de carros e a nossa empresa fictícia se chamará Elite Motors.
